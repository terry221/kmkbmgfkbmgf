
from flask import Flask, render_template, request, redirect, session, url_for
import os
import random, string
import datetime
from helpers import upload_files_to_s3

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Required for session management

# Hardcoded users
users = {
    "user1": "pass1",
    "user2": "pass2",
    "user3": "pass3",
    "user4": "pass4",
    "user5": "pass5"
}

UPLOAD_FOLDER = "upload-aiml-automation"
DATA_SET_FOLDER = "data-set"

@app.route("/", methods=["GET", "POST"])
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        if username in users and users[username] == password:
            session["username"] = username
            return redirect(url_for("index"))
        else:
            return render_template("login.html", error="Invalid credentials")
    return render_template("login.html")

@app.route("/index")
def index():
    if "username" not in session:
        return redirect(url_for("login"))
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    if "username" not in session:
        return redirect(url_for("login"))

    if 'data_file' in request.files:
        data_file = request.files['data_file']

        random_str = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(16))
        millisec_str = str(datetime.datetime.now().timestamp()).replace(".", "")
        date_str = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
        final_random_str = f"{random_str}_{millisec_str}_{date_str}"

        filename, file_extension = os.path.splitext(data_file.filename)
        final_file_name = final_random_str + file_extension

        save_path = os.path.join(UPLOAD_FOLDER, DATA_SET_FOLDER)
        os.makedirs(save_path, exist_ok=True)
        data_file.save(os.path.join(save_path, final_file_name))

        s3_status = upload_files_to_s3(session["username"], final_file_name, DATA_SET_FOLDER, 'data')

        if s3_status == 'True':
            result = 'File uploaded to S3 successfully.'
        else:
            result = 'S3 Upload failed. Internal Server Error.'

    else:
        result = 'No file uploaded.'

    return render_template("index.html", prediction_text=str(result+s3_status))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)
