
import os
import random, string
import datetime
import logging
import boto3
import csv
from botocore.exceptions import ClientError

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "upload-aiml-automation")
S3_BUCKET_NAME = 'awsbucket2199'

s3_client = boto3.client(
    's3',
    aws_access_key_id='AKIA5IJOXCNAP3QZ56EW',
    aws_secret_access_key='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',
)

def upload_files_to_s3(user_id, final_file_name, DATA_SET_FOLDER, purpose_file):
    jdata = 'False'

    try:
        s3_key = f"{user_id}/data/uploaded_file.csv"

        local_file_path = os.path.join(UPLOAD_FOLDER, DATA_SET_FOLDER, final_file_name)

        # Cell validation logic starts here
        with open(local_file_path, encoding='utf_8') as file_data:
            reader = csv.reader(file_data)
            for row_num, row in enumerate(reader, start=1):
                for col_num, cell in enumerate(row, start=1):
                    if cell is None or cell.strip() == '':
                        logging.error(f"Validation Failed: Empty cell found at Row {row_num}, Column {col_num}")
                        return 'Validation Failed: CSV has empty/null values.'

        # If all cells are valid, re-open and upload
        with open(local_file_path, encoding='utf_8') as file_data:
            s3_client.put_object(
                Body=file_data.read(),
                Bucket=S3_BUCKET_NAME,
                Key=s3_key
            )

        if os.path.exists(local_file_path):
            os.remove(local_file_path)

        jdata = 'True'

    except ClientError as e:
        logging.error(e)
        jdata = 'False'

    return jdata
